# html

## 基本结构


```
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>题目</title>
</head>
<body>
    
</body>
</html>
```

所有标签均包含在`<html>`和`</html>`下，称之为根标签。

`lang="en"` lang属性规定元素内容的语言，其中"lang"的意思就是“language”，语言；“en”即表示english；同理，中文为“ch”或“zh-CN”，“Chinese”。

使用`<head>`和`</head>`来标记文件的头部。

​	`<meta charset="UTF-8">` 规定字符集的范围，一般为UTF-8，Unicode，GB2312，GB18030。对于大部分的浏览器，若不指认默认ISO-8859-1。

​	`<meta name>`

​	`<meta content>`

使用`<title>`和`</title>`来标记网页的题目。

使用`<body>`和`</body>`来标记网页的主题，页面内容都是放在`<body>`里面的。


## 文字内容

### 注释

使用`<!--注释内容-->`进行注释

### 标题

使用`<h1>`~`<h6>`来设定标题，`<h1>`级别最高，`<h6>`级别最低。

其中`<h1>`会给logo，使自己的网站在搜索引擎的前面，具体原理未知，`<h2>`才有可能给文字部分。

`align`规定题目居中对齐，HTML5已废弃，使用CSS代替。

```
<h1 align="center">这是标题 1</h1>
<h2 align="left">这是标题 2</h2>
<h3 align="right">这是标题 3</h3>
<h4 align="justify">这是标题 4</h4>
```

### 段落\<p\>

使用`<p>`来标记一个段落。

浏览器会自动换行，使用`<br/>`强制换行换行。

`<p>这是一个段落。</p>`

### 文字格式变化

`<strong>` `</strong>`可以加粗文字，或者使用`<b>` `</b>`标签。

`<em>` `</em>`可以倾斜文字，或者使用`<i>` `</i>`标签。

`<del>` `</del>`可以在文字添加删除线，或者使用`<s>` `</s>`标签。

`<ins>` `</ins>`可以在文字添加下划线，或者使用`<u>` `</u>`标签。

### 文字分区

`<div>`和`</div>`可以将其中的文字分为单独的区域，独占一行。

`<span>`和`</span>`也可以把文字分为单独的区域，但不独占一行。

### 特殊符号

<img src="tupian/image-20231211135545175.png">

### 文字方向

指定文本内容，其中`<bdo>` 标签用来覆盖默认的文本方向。`dir`语句可以指定标记文字顺序的属性，`ltr` 是英文left to right 的首字母缩写，即从左到右。
```
<p>该段落文字从左到右显示。</p>
<p><bdo dir="rtl">该段落文字从右到左显示。</bdo></p>   
```

## 属性

### 文档类型声明

使用`<!DOCTYPE html>`声明当前使用的是HTML5规则。

### 提示文字

使用`<title>`可以创建提示文字

如`<p title="提示文字">停留部分</p>`，鼠标停留到文字上面会出现提示，内嵌于停留部分的标记符号里。

### `HTML <meta> name` 属性



### `HTML DOM Meta` 对象



## 链接

### 超链接

`<href>`指定连接目标的url地址，标签应用`<href>`属性时，就具有了超链接属性。

跳转目标若为#，则为空链接。

跳转目标若为 **#id号** ，则为锚点链接，可以在本页面传送，只需在目标位置设定`<id="id号">`即可。

其中target默认_self(原窗口打开，且为默认值)，\_blank(新窗口打开)。

超链接可以为网址或者文件。

`<a href="跳转目标" target="目标窗口的打开方式">文本或图像 </a>`

## 整洁的展示数据

### 表格

```
<table>(标记表格开始)
<tr>(行开始)
<th>(表头单元格开始)表头单元格内容</th>(表头单元格结束)<th>表头单元格内容</th>
</tr>(行结束)
<tr>(行开始)
<td>(单元格开始)单元格内容</td>(单元格结束)<td>单元格内容</td>
</tr>(行结束)
</table>(标记表格结束)
```

**复制用**

```
<table>
    <tr>
        <th>表头单元格内容</th> <th>表头单元格内容</th>
    </tr>
    
    <tr>
        <td>单元格内容</td> <td>单元格内容</td>
    </tr>
    
</table>
```

![](D:\文档\笔记\前端\HTML\image-20231211152330384.png)

使用`<thead>` 和`</thead>`可以标记表格头部。

使用`<tbody>` 和`</tbody>`可以标记表格主题部分。

#### 合并表格

使用`<rowspan="数字">` 可以合并竖列单元格，数字为行数。

使用`<colspan="数字">` 可以合并横排单元格，数字为列数。

### 列表

#### 无序列表

使用`<ul>`包裹`<li>`实现，`<ul>`仅能出现`<li>`。

```
<ul>
<li>内容1</li>
<li>内容2</li>
</ul>
```

#### 有序列表

与无序列表相比，仅仅是将`<ul>`改为了`<ol>`。

#### 自定义列表

使用

```
<dl>(标记自定义列表开始)
<dt>(自定义列表标题)
</dt>
<dd>(自定义列表内容)
</dd>
</dl>
```

## 表单
```
<form action="url地址" method="提交方式" name="表单域名字">
各类表单组件
</form>
```

### 输入

`<input type="属性值" />`

<img src="tupian/image-20231213152104953.png">

 <img src="tupian/image-20231213152920099.png">



通过`<label>`命令可以延长选择有效区间，点击被`<label>`括起来的部分的内容时会选中有相同ID的内容。

`<label for="id">`文字 `</label>` `<input type="radio" id="id">`

### 下拉菜单

```
<select>(下拉菜单开始)
<option>选项1</option>
<option>选项2</option>
</select>
```

如果有`<select>`内`<option>`包含`<option selected="selected">`则为默认选中。

### 文本域

```
<textarea rows=" " cols="">
文本内容
</textarea>
```

` rows=" " cols=""`已经被CSS代替。

## 线条

### 没有阴影效果的水平线

使用`<hr noshade>`进行标记。 

## 文件类型的音频和图像

### 按钮

若要创建一个按钮，需要使用

`<button type="button">点我!</button>`

进行操作。

其中`<button>`指令用于创建按钮，在其中使用type指令指定`<button>`的属性，`</button>`结束按钮，中间内容为按键内容。

### 绝对路径和相对路径

普通的\a\b\c即为绝对路径，若`/`或`../`即为相对路径，其中`/`代表下一级目录`../`代表上一级目录。

如`<img src="tupian/../目标文件名">`，考虑到上一级目录是唯一的，而下一级目录可能为多个，所以下一级目录表示为`<img src="tupian/下一级目录文件夹名/目标文件名">`

### 插入图片

使用`<img src="tupian/路径">`命令插入图片，考虑到图片无法显示的情况，若在标签内添加`alt="文字"`，则可以在文字无法显示的情况下显示文字，若是使用`<width="数字">`则可以控制图片的宽度，若是使用`<height="数字">`则可以控制图片的高度，若是使用`<border="数字">`则可以给图像添加边框。

也可以添加图片地址。

`    <img src="tupian/路径+文件名" alt="文字" height="数字" width="数字" border="数字" />`

### 插入音频

用`<audio>`标签用于表示插入音频。

```
<audio controls>
  <source src="horse.ogg" type="audio/ogg">
  <source src="horse.mp3" type="audio/mpeg">
  您的浏览器不支持 audio 元素。
</audio>
```
### 插入视频

其中用`<video>`标签用于表示插入视频， `width="320" height="240"`定义视频占位置的长宽

```
<video width="320" height="240" controls>
	<source src="movie.mp4" type="video/mp4">
	<source src="movie.ogg" type="video/ogg">
	您的浏览器不支持video标签
</video>
```

